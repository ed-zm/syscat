This directory contains the Diagra documentation (which is derived
from a sanitised and genericised version of the EPSCHARTS docs).

It now has its own images directory and RML plugins, and depends on
them being there. It will not generate without them.