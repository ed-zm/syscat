This contains example code snippets showing
the encryption API.