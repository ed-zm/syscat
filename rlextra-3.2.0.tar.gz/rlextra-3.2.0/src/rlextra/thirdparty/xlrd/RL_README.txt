This is xlrd-0.9.2 by S J Machin
see http://www.python.org/pypi/xlrd/0.9.2
