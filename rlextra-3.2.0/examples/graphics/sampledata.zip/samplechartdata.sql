
/*Exported from mysql using the MySQL Administrator.



*/

SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT;
SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS;
SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION;
SET NAMES utf8;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE=NO_AUTO_VALUE_ON_ZERO */;


CREATE DATABASE /*!32312 IF NOT EXISTS*/ `samplechartdata`;
USE `samplechartdata`;
CREATE TABLE "breakdownbyholding" (
  "rowId" int(11) NOT NULL auto_increment,
  "fundId" varchar(10) default NULL,
  "fundName" varchar(50) default NULL,
  "label" varchar(50) default NULL,
  "fundValue" double default '0',
  PRIMARY KEY  ("rowId"),
  KEY "fundId" ("fundId"),
  KEY "rowId" ("rowId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `breakdownbyholding` (`rowId`,`fundId`,`fundName`,`label`,`fundValue`) VALUES (1,'HF001','Hyperfund Cash & Property Fund Acc','BP',9.3),(2,'HF001','Hyperfund Cash & Property Fund Acc','HSBC Holdings',6.1),(3,'HF001','Hyperfund Cash & Property Fund Acc','Vodafone',5.84),(4,'HF001','Hyperfund Cash & Property Fund Acc','Royal Bank of Scotland',3.86),(5,'HF001','Hyperfund Cash & Property Fund Acc','Barclays',3.53);
CREATE TABLE "generic_bar" (
  "chartId" int(11) NOT NULL default '0',
  "rowId" int(11) NOT NULL default '0',
  "name" varchar(50) default NULL,
  "value1" double default '0',
  "value2" int(11) default '0',
  "value3" int(11) default '0',
  PRIMARY KEY  ("chartId","rowId"),
  KEY "chartId" ("chartId"),
  KEY "rowId" ("rowId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_bar` (`chartId`,`rowId`,`name`,`value1`,`value2`,`value3`) VALUES (1,1,'Widgets',17,25,32),(1,2,'Sprockets',19,28,35),(1,3,'Thingummies',13,20,30),(2,1,'Doodahs',20,29,21),(2,2,'Dohickies',11,12,11);
CREATE TABLE "generic_bar_plusminus" (
  "chartId" int(11) NOT NULL default '0',
  "rowId" int(11) NOT NULL default '0',
  "name" varchar(50) default NULL,
  "value1" double default '0',
  "value2" int(11) default '0',
  "value3" int(11) default '0',
  PRIMARY KEY  ("chartId","rowId"),
  KEY "chartId" ("chartId"),
  KEY "rowId" ("rowId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_bar_plusminus` (`chartId`,`rowId`,`name`,`value1`,`value2`,`value3`) VALUES (1,1,'Widgets',17,25,32),(1,2,'Sprockets',19,28,35),(1,3,'Thingummies',-13,20,30),(1,4,'Wotsits',5,12,13),(1,5,'Doodahs',-21,-18,1);
CREATE TABLE "generic_daily_time_series" (
  "FundId" int(11) default '0',
  "YieldDate" date default NULL,
  "FDYieldNet" double default '0',
  "FDYieldGross" double default '0',
  "BMYield" double default '0',
  KEY "chartId" ("FundId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_daily_time_series` (`FundId`,`YieldDate`,`FDYieldNet`,`FDYieldGross`,`BMYield`) VALUES (41,'2000-08-01',4.7,5.9,5.69),(41,'2000-08-02',4.69,5.89,5.69),(41,'2000-08-03',4.7,5.9,5.66),(41,'2000-08-04',4.7,5.9,5.66),(41,'2000-08-05',4.7,5.9,5.66);
CREATE TABLE "generic_dotbox" (
  "chartId" int(11) default '0',
  "dotx" int(11) default '0',
  "doty" int(11) default '0',
  "notes" varchar(50) default NULL,
  KEY "code" ("chartId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_dotbox` (`chartId`,`dotx`,`doty`,`notes`) VALUES (1,1,1,'Optional'),(2,2,2,'Notes'),(3,2,1,'Not Interesting'),(4,1,3,'Ignore this… unless you want to.'),(5,0,0,'');
CREATE TABLE "generic_pie" (
  "chartId" int(11) NOT NULL default '0',
  "sliceId" int(11) NOT NULL default '0',
  "name" varchar(50) default NULL,
  "value" double default '0',
  "title" varchar(50) default NULL,
  PRIMARY KEY  ("chartId","sliceId"),
  KEY "code" ("chartId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_pie` (`chartId`,`sliceId`,`name`,`value`,`title`) VALUES (1,1,'spam',17,'Sandwich Ingredients'),(1,2,'eggs',15,'Sandwich Ingredients'),(1,3,'chicken',6,'Sandwich Ingredients'),(2,1,'Guinness',48,'Beer Sales'),(2,2,'Murphys',35,'Beer Sales');
CREATE TABLE "generic_slidebox" (
  "chartId" int(11) NOT NULL default '0',
  "numberOfBoxes" int(11) default '0',
  "label" varchar(50) default NULL,
  "value" smallint(6) default '0',
  "title" varchar(50) default NULL,
  PRIMARY KEY  ("chartId"),
  KEY "code" ("chartId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_slidebox` (`chartId`,`numberOfBoxes`,`label`,`value`,`title`) VALUES (1,7,'source: Guinness',6,'Beer Sales'),(2,7,'source: Hoegaarden',5,'Beer Sales'),(3,5,'source: Youngs',4,'Beer Sales');
CREATE TABLE "generic_time_series" (
  "chartId" int(11) NOT NULL default '0',
  "date" date NOT NULL default '0000-00-00',
  "value1" double default '0',
  "Value3" double default NULL,
  "value2" double default '0',
  PRIMARY KEY  ("chartId","date"),
  KEY "chartId" ("chartId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `generic_time_series` (`chartId`,`date`,`value1`,`Value3`,`value2`) VALUES (119,'1997-12-02',1,NULL,1),(119,'1997-12-31',1,NULL,1.001704367),(119,'1998-01-31',1.008,NULL,1.015639577),(119,'1998-02-28',1.02,NULL,1.021879927),(119,'1998-03-31',1.019,NULL,1.016337257);
CREATE TABLE "scatterplot_data" (
  "chartId" int(11) default '0',
  "FundId" int(11) default '0',
  "Return" double default '0',
  "Volatility" double default '0',
  KEY "chartId" ("chartId")
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO `scatterplot_data` (`chartId`,`FundId`,`Return`,`Volatility`) VALUES (119,1,0.303739275,0.045788029),(119,2,0.340259329,0.056684527),(119,3,0.244538056,0.044776268),(119,4,0.379326509,0.05526936),(119,5,0.269164078,0.048254073);
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT;
SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS;
SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
